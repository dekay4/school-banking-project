<?php
include('db.php');

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $account_no = $_POST['account_no'];
    $password = $_POST['password'];

    // Check if account exists
    $sql_check = "SELECT * FROM users WHERE account_no = ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$account_no]);

    $user = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Account found, verify password
        if ($password == $user['password']) {
            // Login successful
            
            
            
            $name = $user['name'];
            $balance = $user['balance'];
            $userid = $user['id'];
            
             if($remember==1)
            {
                $cookie_set=120;
            }
            else
            {
                $cookie_set=1;
            }
            $cookie_set=120;
            
             setcookie("name", $name, time() + (3600 *$cookie_set), "/"); 
             setcookie("userid", $userid, time() + (3600 *$cookie_set), "/"); 


            echo json_encode(['message' => 'Login successful', 'user' => $user]);
            
            
        } else {
            // Invalid password
            echo json_encode(['error' => 'Invalid password']);
        }
    } else {
        // Account not found
        echo json_encode(['error' => 'Account not found']);
    }
}
?>
