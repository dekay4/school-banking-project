<?php
include('db.php');  // Include your database connection file

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $account_no = $_POST['account_no'];
    $depositAmount = $_POST['depositAmount'];
    $depositReason = $_POST['depositReason'];
    $userid = $_COOKIE['userid'];

    // Validation
    if (empty($account_no) || empty($depositAmount) || empty($depositReason)) {
        echo json_encode(['error' => 'All fields are required.']);
        exit();
    }

    if (!is_numeric($depositAmount) || $depositAmount <= 0) {
        echo json_encode(['error' => 'Deposit amount must be a positive number.']);
        exit();
    }

    try {
        // Check if account exists
        $sql = "SELECT balance FROM users WHERE account_no = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$account_no]);
        $user = $stmt->fetch();

        if (!$user) {
            echo json_encode(['error' => 'Account not found.']);
            exit();
        }

        // Update the balance
        $new_balance = $user['balance'] + $depositAmount;
        $updateSql = "UPDATE users SET balance = ? WHERE account_no = ?";
        $updateStmt = $pdo->prepare($updateSql);
        $updateStmt->execute([$new_balance, $account_no]);

        // Record the deposit transaction (optional)
        $transactionSql = "INSERT INTO transactions (user_id,account_no, amount, reason, transaction_type) VALUES (?, ?, ?, ?, 'deposit')";
        $transactionStmt = $pdo->prepare($transactionSql);
        $transactionStmt->execute([$userid,$account_no, $depositAmount, $depositReason]);

        // Success response
        echo json_encode(['message' => 'Deposit successful.']);

    } catch (PDOException $e) {
        // Handle database error
        echo json_encode(['error' => 'An error occurred: ' . $e->getMessage()]);
    }
}
?>
