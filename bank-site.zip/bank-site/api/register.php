<?php
include('db.php');

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $account_no = $_POST['account_no'];
    $password = $_POST['password'];

    // Check if the account number already exists
    $sql_check = "SELECT COUNT(*) FROM users WHERE account_no = ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$account_no]);
    $exists = $stmt_check->fetchColumn();

    if ($exists) {
        // Account number already exists, throw an error
        echo json_encode(['message' => 'Account number already exists!']);
    } else {
        // Insert data into the users table
        $sql = "INSERT INTO users (name, account_no, password) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $account_no, $password]);

        echo json_encode(['message' => 'User registered successfully!']);
    }
}
?>
