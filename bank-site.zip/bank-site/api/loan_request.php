<?php
include('db.php');

// Check if POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $account_no = $_POST['account_no'];
    $loan_type = $_POST['loan_type'];
    $amount = $_POST['amount'];

    // Fetch user from the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE account_no = ?");
    $stmt->execute([$account_no]);
    $user = $stmt->fetch();

    if ($user) {
        // Insert loan request
        $stmt = $pdo->prepare("INSERT INTO loan_requests (user_id, loan_type, amount) VALUES (?, ?, ?)");
        $stmt->execute([$user['id'], $loan_type, $amount]);

        echo json_encode(['message' => 'Loan request submitted successfully!']);
    } else {
        echo json_encode(['message' => 'User not found!']);
    }
}
