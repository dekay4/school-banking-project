<?php
include('db.php'); // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $currentPin = $_POST['currentPin'];
    $newPin = $_POST['newPin'];
    $confirmPin = $_POST['confirmPin'];
    $userid = $_COOKIE['userid']; // Assuming the user ID is stored in a cookie

    // Validation checks
    if (empty($currentPin) || empty($newPin) || empty($confirmPin)) {
        echo json_encode(['error' => 'All fields are required.']);
        exit();
    }

    if ($newPin !== $confirmPin) {
        echo json_encode(['error' => 'New PIN and Confirm PIN do not match.']);
        exit();
    }

    try {
        // Verify current PIN
        $sql = "SELECT password FROM users WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userid]);
        $user = $stmt->fetch();

        if (!$user || $user['password'] !== $currentPin) {
            echo json_encode(['error' => 'Incorrect current PIN.']);
            exit();
        }

        // Update the PIN
        $updateSql = "UPDATE users SET password = ? WHERE id = ?";
        $updateStmt = $pdo->prepare($updateSql);
        $updateStmt->execute([$newPin, $userid]);

        // Success response
        echo json_encode(['message' => 'PIN updated successfully.']);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'An error occurred: ' . $e->getMessage()]);
    }
}
?>
