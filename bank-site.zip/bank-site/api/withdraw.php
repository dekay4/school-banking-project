<?php
include('db.php');  // Include your database connection file

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $account_no = $_POST['account_no'];
    $withdrawAmount = $_POST['withdrawAmount'];
    $withdrawReason = $_POST['withdrawReason'];
    $userid = $_COOKIE['userid']; // assuming user ID is stored in a cookie

    // Validation
    if (empty($account_no) || empty($withdrawAmount) || empty($withdrawReason)) {
        echo json_encode(['error' => 'All fields are required.']);
        exit();
    }

    if (!is_numeric($withdrawAmount) || $withdrawAmount <= 0) {
        echo json_encode(['error' => 'Withdrawal amount must be a positive number.']);
        exit();
    }

    try {
        // Check if account exists and retrieve current balance
        $sql = "SELECT balance FROM users WHERE account_no = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$account_no]);
        $user = $stmt->fetch();

        if (!$user) {
            echo json_encode(['error' => 'Account not found.']);
            exit();
        }

        // Check if there is enough balance for withdrawal
        if ($user['balance'] < $withdrawAmount) {
            echo json_encode(['error' => 'Insufficient funds.']);
            exit();
        }

        // Deduct the withdrawal amount from the balance
        $new_balance = $user['balance'] - $withdrawAmount;
        $updateSql = "UPDATE users SET balance = ? WHERE account_no = ?";
        $updateStmt = $pdo->prepare($updateSql);
        $updateStmt->execute([$new_balance, $account_no]);

        // Record the withdrawal transaction in the transactions table
        $transactionSql = "INSERT INTO transactions (user_id, account_no, amount, reason, transaction_type) VALUES (?, ?, ?, ?, 'withdrawal')";
        $transactionStmt = $pdo->prepare($transactionSql);
        $transactionStmt->execute([$userid, $account_no, $withdrawAmount, $withdrawReason]);

        // Success response
        echo json_encode(['message' => 'Withdrawal successful.']);

    } catch (PDOException $e) {
        // Handle database error
        echo json_encode(['error' => 'An error occurred: ' . $e->getMessage()]);
    }
}
?>
