<?php
$host = "localhost"; // Change it to your database host if needed
$dbname = "u443072320_crm";
$username = "u443072320_crm"; // Database username
$password = "8bI:!SY4qB+k"; // Database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}
