<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Transaction History - Banking Project</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="assets/js/script.js" defer></script>
        <link href="https://fonts.cdnfonts.com/css/azonix" rel="stylesheet" />

    <style>
      body,
      html {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        background: linear-gradient(135deg, #2e1a47, #6a1b9a);

        display: flex;
        justify-content: center;
        align-items: center;
      }

      .transaction-card {
        width: 80%;
        padding: 25px;
        border-radius: 15px;
        backdrop-filter: blur(10px);
        background-color: rgba(0, 0, 0, 0.7);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        color: white;
      }

      .transaction-card h2 {
        text-align: center;
        margin-bottom: 30px;
        color: #fff;
      }

      .table {
        background-color: rgba(255, 255, 255, 0.2);
        color: #fff;
        border-radius: 10px;
      }

      .table thead {
        background-color: #9c27b0;
      }

      .table th,
      .table td {
        padding: 15px;
        text-align: center;
      }

      .btn-primary {
        background-color: #9c27b0;
        border: none;
        width: 100%;
        padding: 10px;
        border-radius: 10px;
        font-size: 1.1rem;
        transition: background-color 0.3s ease;
      }

      .btn-primary:hover {
        background-color: #7b1fa2;
      }

      footer {
        position: fixed;
        bottom: 10px;
        width: 100%;
        text-align: center;
        color: #fff;
        font-size: 0.9em;
      }
       .logo {
        font-family: "Azonix", sans-serif;
        text-align: center;
      }
    </style>
  </head>

  <body>
    <div class="transaction-card">
              <h1 class="logo">Stud Bank</h1>

      <h2>Transaction History</h2>

      <!-- Transaction Table -->
      <div class="table-responsive">
          <?php
          
          include('api/db.php'); // Include your database connection file

$user_id =  $_COOKIE['userid']; // Assuming user ID is stored in session or cookies

          
            $sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY transaction_date DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$user_id]);
        
            $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($transactions) {


    
      
          ?>
          
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Sno</th>
              <!--<th>Transaction ID</th>-->
              <th>Account No</th>
              <th>Amount (INR)</th>
              <th>Reason</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <!-- Example Transaction Row -->
            <?php 
            $sno = 0;
           foreach ($transactions as $transaction) {
                $sno++;

            ?>
            <tr>
              <td><?php echo $sno;?></td>
              <!--<td><?php //echo htmlspecialchars($transaction['transaction_id'])?></td>-->
              <td><?php echo htmlspecialchars($transaction['account_no']) ?></td>
              <td><?php echo htmlspecialchars($transaction['amount']) ?></td>
              <td><?php echo htmlspecialchars($transaction['reason']) ?></td>
              <td><?php echo htmlspecialchars($transaction['transaction_date']) ?></td>
              <td><span class="badge <?php echo htmlspecialchars($transaction['transaction_type']) == 'deposit' ? 'bg-success' : 'bg-danger' ?>"><?php echo htmlspecialchars($transaction['transaction_type']) ?></span></td>
            </tr>
            <?php 
            
                    }
            ?>
         
          </tbody>
        </table>
        <?php 
        
          } else {
              ?>
              <h1 style="text-align:center;">No Record Found ☹️</h1>
          <?php    
          }
        ?>
      </div>
      <p class="text-center mt-3">
        <a href="dashboard.php" class="text-light">Back to Dashboard</a>
      </p>
    </div>

    <footer>&copy; 2025 YourBank. All Rights Reserved.</footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
  </body>
</html>
