<!DOCTYPE html>
<?php

include('api/db.php');


$userid = $_COOKIE['userid'];

    // Check if account exists
    $sql_check = "SELECT * FROM users WHERE id = ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$userid]);

    $user = $stmt_check->fetch(PDO::FETCH_ASSOC);
    $balance = $user['balance'];


?>




<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Dashboard</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-KyZXEJt3W2XjRkI6uWc6LhC1m4FFvGr80c9gLw6RoQY5hYcz7y75kIjOGc6vEG1t"
      crossorigin="anonymous"
    />
        <link href="https://fonts.cdnfonts.com/css/azonix" rel="stylesheet" />

    <style>
      body {
        background: linear-gradient(135deg, #2e1a47, #6a1b9a);
        color: white;
        font-family: "Poppins", sans-serif;
      }

      .container {
        max-width: 100%;
        margin-top: 50px;
        margin-left: 20px; /* Added left margin */
        margin-right: 20px; /* Added right margin */
      }

      .card {
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        background-color: rgba(0, 0, 0, 0.8);
        margin: 20px 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%; /* Flexible height */
        transition: all 0.3s ease; /* Smooth transition for hover effect */
      }

      .card-header {
        background-color: #3d0056;
        border-bottom: 2px solid #9c27b0;
        text-align: center;
        font-size: 24px;
        font-weight: bold;
      }

      .card-body {
        padding: 20px;
        text-align: center;
      }

      .btn {
        background: linear-gradient(135deg, #6a1b9a, #9c27b0);
        border: none;
        transition: transform 0.3s ease-in-out;
        width: 100%;
        margin-top: 10px;
      }

      .btn:hover {
        transform: scale(1.05);
      }

      .card-link {
        color: #9c27b0;
        font-size: 18px;
        text-decoration: none;
      }

      .card-link:hover {
        color: #6a1b9a;
        text-decoration: underline;
      }

      .row {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
      }

      .col-md-4 {
        margin-bottom: 83px;
        width: 30%; /* Adjusting width for better fitting */
      }

      .link-card {
        text-align: center;
        padding: 20px;
      }

      .link-card i {
        font-size: 50px;
        color: #9c27b0;
        margin-bottom: 10px;
      }

      .link-card h5 {
        font-size: 20px;
        font-weight: bold;
      }

      .bank-balance {
        text-align: center;
        margin-bottom: 30px;
        font-size: 30px;
      }

      /* Neon Glow Effect on Hover */
      .card:hover {
        box-shadow: 0 0 20px rgba(156, 39, 176, 0.8),
          0 0 40px rgba(156, 39, 176, 0.6), 0 0 60px rgba(156, 39, 176, 0.4);
        transform: translateY(-10px); /* Slight lift on hover */
      }
      
      
      /* Logout Button Style */
      .logout-btn {
        background: linear-gradient(135deg, #e91e63, #9c27b0);
        border: none;
        padding: 10px 20px;
        font-size: 18px;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        display: inline-block;
        margin-top: 20px;
        float: right;
      }

      .logout-btn:hover {
        transform: scale(1.05);
        box-shadow: 0 0 20px rgba(156, 39, 176, 0.6);
      }
       .logo {
        font-family: "Azonix", sans-serif;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <div class="container">
          <div class="text-end">
        <a href="index.html" class="logout-btn">Logout</a>
      </div>

      <!-- Bank Balance Section -->
      <div class="bank-balance">
                <h1 class="logo">Stud Bank</h1>

        <h2 class="text-center text-light mb-5">Welcome <?php echo $_COOKIE['name']?></h2>

        <h3>💰 Your Bank Balance: ₹<?php echo $balance?> 💳</h3>
      </div>

      <div class="row">
        <!-- Deposit Card -->
        <div class="col-md-4">
          <div class="card link-card">
            <i class="fas fa-dollar-sign"></i>
            <h5>Deposit Money</h5>
            <a href="deposit.html" class="card-link">Deposit Now</a>
          </div>
        </div>

        <!-- Withdraw Card -->
        <div class="col-md-4">
          <div class="card link-card">
            <i class="fas fa-arrow-down"></i>
            <h5>Withdraw Money</h5>
            <a href="withdraw.html" class="card-link">Withdraw Now</a>
          </div>
        </div>

        <!-- Update PIN Card -->
        <div class="col-md-4">
          <div class="card link-card">
            <i class="fas fa-key"></i>
            <h5>Update PIN</h5>
            <a href="update-pin.html" class="card-link">Update PIN</a>
          </div>
        </div>

        <!-- Loan Request Card -->
        <div class="col-md-4">
          <div class="card link-card">
            <i class="fas fa-hand-holding-usd"></i>
            <h5>Request Loan</h5>
            <a href="loan.html" class="card-link">Request Now</a>
          </div>
        </div>

        <!-- Card Block Card -->
        <div class="col-md-4">
          <div class="card link-card">
            <i class="fas fa-credit-card"></i>
            <h5>Card Block</h5>
            <a href="block-card.html" class="card-link">Block Card</a>
          </div>
        </div>

        <!-- New Card 6 -->
        <div class="col-md-4">
          <div class="card link-card">
            <i class="fas fa-cogs"></i>
            <h5>Transaction</h5>
            <a href="transaction.php" class="card-link">transaction history</a>
          </div>
        </div>
      </div>
    </div>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"
      integrity="sha384-pzjw8f+ua7Kw1TIq0evLkXedR6QfQt0rC2Q7n6ED+5ntvn/d8TY0BfeCh8mrF0c3"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
